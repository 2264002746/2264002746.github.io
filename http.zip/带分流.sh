rm -rf ./核心/cache.db
rm -rf ./核心/nohup.out
rm -rf ./核心/*.txt
#clash部分
nohup ./核心/clash -f ./核心/分流.yaml -d ./核心/ 1&2>./核心/clash.txt
#xray部分
nohup ./核心/xray -config ./核心/xray.json 1&2>./核心/xray.txt
exit