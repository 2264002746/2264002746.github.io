killall clash
killall xray